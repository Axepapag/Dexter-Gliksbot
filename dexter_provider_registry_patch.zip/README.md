# Dexter Provider Registry — Patch Bundle

This bundle adds a future‑proof provider registry (Ollama + NVIDIA + Perplexity + GitHub Models + any OpenAI‑compatible) and slot/YAML sync support.

## Files included
- `agents/providers/base.py`
- `agents/providers/ollama.py`
- `agents/providers/openai_compat.py`
- `agents/providers/presets.py`
- `agents/providers/registry.py`
- `configs/slots.py` (YAML read/write/validate + atomic save)
- `patches/patch_ui_bridge_api.diff` (apply to `ui_bridge/api.py`)
- `examples/slots.example.yml`

## Apply steps (safe)
1) **Copy new modules**
   - Create folder `agents/providers/` if it doesn't exist.
   - Copy all `agents/providers/*.py` files into your repo.
   - Copy `configs/slots.py` into your repo.

2) **Patch FastAPI app**
   - Apply `patches/patch_ui_bridge_api.diff` to your `ui_bridge/api.py` (unified diff). If patch fails, open the diff and manually add the small route blocks.

3) **Add example config**
   - Place `examples/slots.example.yml` as `configs/slots.yml` (or merge with yours).

4) **Env vars (example)**
   ```bash
   # Default (Ollama)
   OLLAMA_HOST=http://127.0.0.1:11434
   OLLAMA_MODEL=llama3.1

   # Perplexity
   PPLX_API_KEY=...
   PPLX_BASE_URL=https://api.perplexity.ai
   PPLX_MODEL=llama-3.1-sonar-small-online

   # NVIDIA
   NVIDIA_API_KEY=...
   NVIDIA_BASE_URL=https://integrate.api.nvidia.com/v1
   NVIDIA_MODEL=meta/llama-3.1-70b-instruct

   # GitHub Models
   GITHUB_TOKEN=...
   GITHUB_MODELS_BASE_URL=https://models.inference.ai.azure.com
   GITHUB_MODEL=gpt-4o-mini
   ```

5) **Wire the orchestrator**
   - Replace any direct `OllamaClient` usage with:
     ```python
     from agents.providers.registry import get_provider
     prov = get_provider(slot.provider)         # slot from YAML or UI
     resp = prov.chat(messages, model=slot.model, temperature=slot.temperature)
     ```

6) **Run**
   - Start your backend and call:
     - `GET /providers` → `["ollama","perplexity","nvidia","github"]`
     - `GET /slots` → YAML content
     - `POST /dexter/chat` with `{slot_id, messages}`

## Notes
- This patch is **backwards compatible**: if you leave everything pointing to Ollama, behavior is unchanged.
- Add more providers by extending `agents/providers/presets.py`.
