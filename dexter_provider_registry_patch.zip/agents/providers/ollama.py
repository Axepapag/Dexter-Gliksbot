from __future__ import annotations
from typing import Dict, Any, List, Optional
import os, requests
from .base import LLMProvider, ProviderError

class OllamaProvider:
    name = "ollama"
    def __init__(self):
        self.base_url = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
        self.default_model = os.getenv("OLLAMA_MODEL", "")
        self.headers = {}

    def health(self) -> Dict[str, Any]:
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=4)
            return {"ok": r.ok, "status": r.status_code, "endpoint": self.base_url}
        except Exception as e:
            return {"ok": False, "error": str(e), "endpoint": self.base_url}

    def chat(self, messages: List[Dict[str, str]], *, model: Optional[str] = None, temperature: Optional[float] = None, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}/api/chat"
        body: Dict[str, Any] = {"model": model or self.default_model, "messages": messages}
        opts = {}
        if temperature is not None:
            opts["temperature"] = temperature
        opts.update(kwargs.get("options", {}))
        if opts:
            body["options"] = opts
        r = requests.post(url, json=body, headers=self.headers, timeout=60)
        if r.status_code >= 400:
            raise ProviderError(f"ollama {r.status_code}: {r.text}")
        return r.json()

    def embeddings(self, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}/api/embeddings"
        r = requests.post(url, json=kwargs, headers=self.headers, timeout=60)
        if r.status_code >= 400:
            raise ProviderError(f"ollama {r.status_code}: {r.text}")
        return r.json()
