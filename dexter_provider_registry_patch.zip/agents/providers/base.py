from __future__ import annotations
from typing import Protocol, Dict, Any, List, Optional

class LLMProvider(Protocol):
    name: str
    def health(self) -> Dict[str, Any]: ...
    def chat(self, messages: List[Dict[str, str]], *, model: Optional[str] = None, temperature: Optional[float] = None, **kwargs) -> Dict[str, Any]: ...
    def embeddings(self, **kwargs) -> Dict[str, Any]: ...

class ProviderError(RuntimeError):
    pass
