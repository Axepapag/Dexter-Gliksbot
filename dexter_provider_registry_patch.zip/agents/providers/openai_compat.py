from __future__ import annotations
from typing import Dict, Any, List, Optional
import os, requests
from .base import LLMProvider, ProviderError

class OpenAICompatProvider:
    """Generic adapter for OpenAI-compatible endpoints (/chat/completions, /embeddings)."""
    def __init__(self, name: str, base_env: str, key_env: str, model_env: Optional[str] = None, default_base: Optional[str] = None):
        self.name = name
        base = os.getenv(base_env, (default_base or "")).rstrip("/")
        if not base:
            raise RuntimeError(f"{name}: missing base URL env {base_env}")
        self.base_url = base
        key = os.getenv(key_env, "")
        if not key:
            raise RuntimeError(f"{name}: missing API key env {key_env}")
        self.headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        self.default_model = os.getenv(model_env, "") if model_env else ""

    def health(self) -> Dict[str, Any]:
        try:
            url = f"{self.base_url}/chat/completions"
            r = requests.post(url, headers=self.headers, json={"model": self.default_model or "", "messages": [{"role": "user", "content": "ping"}], "max_tokens": 1}, timeout=6)
            return {"ok": r.status_code < 500, "status": r.status_code, "endpoint": self.base_url}
        except Exception as e:
            return {"ok": False, "error": str(e), "endpoint": self.base_url}

    def chat(self, messages: List[Dict[str, str]], *, model: Optional[str] = None, temperature: Optional[float] = None, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}/chat/completions"
        body: Dict[str, Any] = {"model": model or self.default_model, "messages": messages}
        if temperature is not None: body["temperature"] = temperature
        for k in ("top_p","max_tokens","frequency_penalty","presence_penalty"):
            if k in kwargs: body[k] = kwargs[k]
        r = requests.post(url, json=body, headers=self.headers, timeout=90)
        if r.status_code >= 400:
            try:
                detail = r.json()
            except Exception:
                detail = {"text": r.text}
            raise ProviderError(f"{self.name} {r.status_code}: {detail}")
        return r.json()

    def embeddings(self, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}/embeddings"
        r = requests.post(url, json=kwargs, headers=self.headers, timeout=90)
        if r.status_code >= 400:
            raise ProviderError(f"{self.name} {r.status_code}: {r.text}")
        return r.json()
