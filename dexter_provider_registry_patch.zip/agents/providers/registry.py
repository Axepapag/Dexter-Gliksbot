from __future__ import annotations
from typing import Dict
from .base import LLMProvider
from . import presets

_singletons: Dict[str, LLMProvider] = {}

def list_providers() -> list[str]:
    return list(presets.PRESET_FACTORIES.keys())

def get_provider(name: str) -> LLMProvider:
    name = name.lower()
    if name not in _singletons:
        if name not in presets.PRESET_FACTORIES:
            raise KeyError(f"unknown provider: {name}")
        _singletons[name] = presets.PRESET_FACTORIES[name]()
    return _singletons[name]
