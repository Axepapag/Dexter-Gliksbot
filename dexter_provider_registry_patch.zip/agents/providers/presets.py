from __future__ import annotations
from .ollama import OllamaProvider
from .openai_compat import OpenAICompatProvider

# Built-in presets (instantiate lazily in registry)
PRESET_FACTORIES = {
    "ollama": lambda: OllamaProvider(),
    "perplexity": lambda: OpenAICompatProvider(
        name="perplexity", base_env="PPLX_BASE_URL", key_env="PPLX_API_KEY", model_env="PPLX_MODEL", default_base="https://api.perplexity.ai"
    ),
    "nvidia": lambda: OpenAICompatProvider(
        name="nvidia", base_env="NVIDIA_BASE_URL", key_env="NVIDIA_API_KEY", model_env="NVIDIA_MODEL", default_base="https://integrate.api.nvidia.com/v1"
    ),
    "github": lambda: OpenAICompatProvider(
        name="github", base_env="GITHUB_MODELS_BASE_URL", key_env="GITHUB_TOKEN", model_env="GITHUB_MODEL"
    ),
    # Extend with openai, azure_openai, anthropic, groq, lmstudio, etc.
}
