from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
import yaml, hashlib, tempfile, os, shutil

class Slot(BaseModel):
    id: str
    name: str
    provider: str = Field(default="ollama")
    endpoint: Optional[str] = None
    model: Optional[str] = None
    api_key_env: Optional[str] = None
    temperature: Optional[float] = None
    prompt: Optional[str] = None
    params: Dict[str, Any] | None = None

class SlotsConfig(BaseModel):
    slots: List[Slot] = Field(default_factory=list)

class SlotsStore:
    def __init__(self, path: str = "configs/slots.yml"):
        self.path = path
        self.data = self._read()
        self.hash = self._hash()

    def _read(self) -> SlotsConfig:
        if not os.path.exists(self.path):
            return SlotsConfig(slots=[])
        with open(self.path, "r", encoding="utf-8") as f:
            return SlotsConfig.model_validate(yaml.safe_load(f) or {"slots": []})

    def _hash(self) -> str:
        raw = yaml.safe_dump(self.data.model_dump())
        return hashlib.sha1(raw.encode()).hexdigest()

    def as_dict(self):
        return self.data.model_dump()

    def by_id(self, slot_id: str) -> Slot | None:
        return next((s for s in self.data.slots if s.id == slot_id), None)

    def upsert(self, slot: dict):
        incoming = Slot.model_validate(slot)
        for i, s in enumerate(self.data.slots):
            if s.id == incoming.id:
                self.data.slots[i] = incoming; break
        else:
            self.data.slots.append(incoming)
        self.save()

    def delete(self, slot_id: str):
        self.data.slots = [s for s in self.data.slots if s.id != slot_id]
        self.save()

    def save(self):
        tmp_fd, tmp_path = tempfile.mkstemp(prefix="slots_", suffix=".yml")
        os.close(tmp_fd)
        with open(tmp_path, "w", encoding="utf-8") as f:
            yaml.safe_dump(self.data.model_dump(), f, sort_keys=False, allow_unicode=True)
        shutil.move(tmp_path, self.path)
        self.hash = self._hash()

_store: SlotsStore | None = None

def get_store() -> SlotsStore:
    global _store
    if _store is None:
        _store = SlotsStore()
    return _store
